Code2Video export bundle for trigonometry-explain-easily-30-secs-20251115121026

Contents:
- trigonometry-explain-easily-30-secs-20251115121026.py : Generated Manim script

Render locally:
    manim -p -r 1920,1080 -q h trigonometry-explain-easily-30-secs-20251115121026.py GeneratedScene
