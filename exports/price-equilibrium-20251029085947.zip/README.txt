EconViz Local export bundle for price-equilibrium-20251029085947

Contents:
- price-equilibrium-20251029085947.py : Manim script
- price-equilibrium-20251029085947.json : Storyboard beats

Run:
    manim -p -r 1920,1080 -q h price-equilibrium-20251029085947.py EconScene
