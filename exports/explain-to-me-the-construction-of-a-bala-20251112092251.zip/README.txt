Code2Video export bundle for explain-to-me-the-construction-of-a-bala-20251112092251

Contents:
- explain-to-me-the-construction-of-a-bala-20251112092251.py : Generated Manim script

Render locally:
    manim -p -r 1920,1080 -q h explain-to-me-the-construction-of-a-bala-20251112092251.py GeneratedScene
