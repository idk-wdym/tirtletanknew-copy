EconViz Local export bundle for basic-economics-problem-on-scarcity-20251026130648

Contents:
- basic-economics-problem-on-scarcity-20251026130648.py : Manim script
- basic-economics-problem-on-scarcity-20251026130648.json : Storyboard beats

Run:
    manim -p -r 1920,1080 -q h basic-economics-problem-on-scarcity-20251026130648.py EconScene
