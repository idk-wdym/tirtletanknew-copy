EconViz Local export bundle for demand-and-supply-20251026124847

Contents:
- demand-and-supply-20251026124847.py : Manim script
- demand-and-supply-20251026124847.json : Storyboard beats

Run:
    manim -p -r 1920,1080 -q h demand-and-supply-20251026124847.py EconScene
