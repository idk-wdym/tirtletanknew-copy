Code2Video export bundle for basic-economic-problem-20251112044740

Contents:
- basic-economic-problem-20251112044740.py : Generated Manim script

Render locally:
    manim -p -r 1920,1080 -q h basic-economic-problem-20251112044740.py GeneratedScene
