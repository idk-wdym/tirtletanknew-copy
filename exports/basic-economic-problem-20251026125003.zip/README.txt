EconViz Local export bundle for basic-economic-problem-20251026125003

Contents:
- basic-economic-problem-20251026125003.py : Manim script
- basic-economic-problem-20251026125003.json : Storyboard beats

Run:
    manim -p -r 1920,1080 -q h basic-economic-problem-20251026125003.py EconScene
