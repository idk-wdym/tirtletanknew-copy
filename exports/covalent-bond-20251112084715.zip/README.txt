Code2Video export bundle for covalent-bond-20251112084715

Contents:
- covalent-bond-20251112084715.py : Generated Manim script

Render locally:
    manim -p -r 1920,1080 -q h covalent-bond-20251112084715.py GeneratedScene
