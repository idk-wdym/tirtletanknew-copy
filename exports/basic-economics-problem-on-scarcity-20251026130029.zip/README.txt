EconViz Local export bundle for basic-economics-problem-on-scarcity-20251026130029

Contents:
- basic-economics-problem-on-scarcity-20251026130029.py : Manim script
- basic-economics-problem-on-scarcity-20251026130029.json : Storyboard beats

Run:
    manim -p -r 1920,1080 -q h basic-economics-problem-on-scarcity-20251026130029.py EconScene
