EconViz Local export bundle for price-equilibrium-20251029085336

Contents:
- price-equilibrium-20251029085336.py : Manim script
- price-equilibrium-20251029085336.json : Storyboard beats

Run:
    manim -p -r 1920,1080 -q h price-equilibrium-20251029085336.py EconScene
